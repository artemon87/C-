//
//  main.cpp
//  332Lab
//
//  Created by Artem Kovtunenko on 10/3/14.
//  Copyright (c) 2014 Artem Kovtunenko. All rights reserved.
//

#include <iostream>

using namespace std;
const int TEAM_SIZE=50;

class Player {
    
private:
    string fname;
    string lname;
    int number;
    
public:
    
    Player(){};
    Player(string fName, string  lName, int num)
    {
        cout<<"Class was created of type PLAYER with paramenters"<<endl;
        fname=fName;
        lname=lName;
        number=num;
    }
    void setPlayer(string fName, string  lName, int num){fname=fName; lname=lName; number=num;}
    int getNumber() const{return number;}
    string getFullName()const{return fname;}
    void sutNumber(int num){number=num;}
    
};

class Roster
{
private:
    Player player[TEAM_SIZE];
    
public:
    Roster()
    {
        
    }
    Roster(string team){cout<<team<<" team was created"<<endl;}
    
    void AddPlayer(const Player &player)
    {
      cout<<"You just added a player"<<endl;
    }
    void RemovePlayer(const Player &player);
    void PrintRoster();
    
    Player getPlayerByNumber(int num)const;
    Player getlayerByName(string fname, string lname)const;
    bool IsOnTeam(const Player &player);
};


int main() {
    
    cout<<"wellcome"<<endl;
    Roster seahawks("Seahawks");
    Player p1("Russel", "Wilson", 3);
    Player p2("Spiro", "Agnew", 7);
    Player p3("Tony", "Blair", 14);
    //p1.setPlayer("Russel", "Wilson", 3);
    seahawks.AddPlayer(p1);
    
    
    
    // Players player (playerLName, playerFName, number);
    return 0;
}
  

