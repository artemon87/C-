//
//  History.h
//  BinarySearchTree
//
//  Created by Artem Kovtunenko on 12/2/14.
//  Copyright (c) 2014 Artem Kovtunenko. All rights reserved.
//

#ifndef __BinarySearchTree__History__
#define __BinarySearchTree__History__

#include <stdio.h>
#include "Transaction.h"
//#include "Account.h"
#include <vector>
#include <string>

using namespace std;

class HistoryObj
{
private:
    
    vector<Transaction*> MoneyMarket;
    vector<Transaction*> PrimeMoneyMarket;
    vector<Transaction> LongTermBond;
    vector<Transaction> ShortTermBond;
    vector<Transaction> IndexFund;
    vector<Transaction> CapitalValueFund;
    vector<Transaction> GrowthEquityFund;
    vector<Transaction> GrowthIndexFund;
    vector<Transaction> ValueFund;
    vector<Transaction> ValueStockIndex;
    
public:
    HistoryObj();
    ~HistoryObj();
    void addToHistory(Transaction &trans, int ID);
    void displayHistory(Transaction &trans);
    void displayHistory(int ID, Transaction &trans);
    
};

#endif /* defined(__BinarySearchTree__History__) */
