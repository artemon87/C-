//
//  History.cpp
//  BinarySearchTree
//
//  Created by Artem Kovtunenko on 12/2/14.
//  Copyright (c) 2014 Artem Kovtunenko. All rights reserved.
//

#include "HistoryObj.h"
#include <vector>
#include <string>

using namespace std;

HistoryObj:: HistoryObj()
{
}
HistoryObj:: ~HistoryObj()
{}
void HistoryObj:: addToHistory(Transaction &trans, int ID)
{
    if(ID==0)
    {
        MoneyMarket.push_back(&trans);
    }
    else if(ID==1)
    {
        PrimeMoneyMarket.push_back(&trans);
    }
    else if(ID==2)
    {
        LongTermBond.push_back(trans);
    }
    else if(ID==3)
    {
        ShortTermBond.push_back(trans);
    }
    else if(ID==4)
    {
        IndexFund.push_back(trans);
    }
    else if(ID==5)
    {
        CapitalValueFund.push_back(trans);
    }
    else if(ID==6)
    {
        GrowthEquityFund.push_back(trans);
    }
    else if(ID==7)
    {
        GrowthIndexFund.push_back(trans);
    }
    else if(ID==8)
    {
        ValueFund.push_back(trans);
    }
    else if(ID==9)
    {
        ValueStockIndex.push_back(trans);
    }
}
void HistoryObj:: displayHistory(Transaction &trans)
{
    if(!MoneyMarket.empty())
    {
        for(int i=0; i<MoneyMarket.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!PrimeMoneyMarket.empty())
    {
        for(int i=0; i<PrimeMoneyMarket.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!LongTermBond.empty())
    {
        for(int i=0; i<LongTermBond.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!ShortTermBond.empty())
    {
        for(int i=0; i<ShortTermBond.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!IndexFund.empty())
    {
        for(int i=0; i<IndexFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!CapitalValueFund.empty())
    {
        for(int i=0; i<CapitalValueFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!GrowthEquityFund.empty())
    {
        for(int i=0; i<GrowthEquityFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!GrowthIndexFund.empty())
    {
        for(int i=0; i<GrowthIndexFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!ValueFund.empty())
    {
        for(int i=0; i<ValueFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    if(!ValueStockIndex.empty())
    {
        for(int i=0; i<ValueStockIndex.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
}
void HistoryObj:: displayHistory(int ID, Transaction &trans)
{
    if(ID==0)
    {
        for(int i=0; i<MoneyMarket.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==1)
    {
        for(int i=0; i<PrimeMoneyMarket.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==2)
    {
        for(int i=0; i<LongTermBond.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==3)
    {
        for(int i=0; i<ShortTermBond.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==4)
    {
        for(int i=0; i<IndexFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==5)
    {
        for(int i=0; i<CapitalValueFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==6)
    {
        for(int i=0; i<GrowthEquityFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==7)
    {
        for(int i=0; i<GrowthIndexFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==8)
    {
        for(int i=0; i<ValueFund.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else if(ID==9)
    {
        for(int i=0; i<ValueStockIndex.size(); i++)
        {
            cout<<trans;
        }
        cout<<endl;
    }
    else
    {
        cout<<"This account is empty"<<endl;
    }
}